# frozen_string_literal: false
# this is a dummy file used by test/dtrace/test_require.rb
